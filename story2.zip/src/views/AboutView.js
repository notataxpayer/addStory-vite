export default {
    render(container) {
      container.innerHTML = `
        <section>
          <h2>About Page</h2>
          <p>This is a simple About page.</p>
        </section>
      `;
    },
  };
  